package com.wf.apps.interviewApp.dto;

import lombok.Data;

@Data
public class interviewCountDto {
	
	private Integer noOfInterviews;

}
