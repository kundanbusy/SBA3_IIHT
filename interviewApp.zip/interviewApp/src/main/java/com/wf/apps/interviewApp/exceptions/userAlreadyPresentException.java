package com.wf.apps.interviewApp.exceptions;

public class userAlreadyPresentException {

}
